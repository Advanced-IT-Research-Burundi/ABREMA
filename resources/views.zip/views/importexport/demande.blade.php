@extends('layouts.base')

@section('title', 'Profil de l\'ABREMA')

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/pages.css') }}">
@endsection

@section('content')
    <!-- PAGE BANNER -->
    <div class="page-banner">
        <div class="container-fluid">
            <h1>Importations et Exportations</h1>
            <p class="lead">Autorité Burundaise de Régulation des Médicaments à usage humain et des Aliments</p>
        </div>
    </div>

    <!-- MAIN LAYOUT -->
    <div class="main-layout">
        <div class="container-fluid">
            <div class="layout-row">

               <!-- SIDEBAR NAV -->
                <aside class="sidebar-nav">
                    <h3>Navigation</h3>
                    <nav class="nav flex-column">
                        <a class="nav-link {{ Route::is('about.profilabrema') ? 'active' : '' }}" href="{{ route('about.profilabrema') }}">Profil global d'ABREMA</a>
                        <a class="nav-link {{ Route::is('about.organigramme') ? 'active' : '' }}" href="{{ route('about.organigramme') }}">Organigramme</a>
                        <a class="nav-link {{ Route::is('about.equipe') ? 'active' : '' }}" href="{{ route('about.equipe') }}">Équipe de Direction</a>
                        <a class="nav-link {{ Route::is('about.fonction') ? 'active' : '' }}" href="{{ route('about.fonction') }}">Fonction Réglementaire</a>
                        <a class="nav-link {{ Route::is('about.qms') ? 'active' : '' }}" href="{{ route('about.qms') }}">QMS</a>
                    </nav>
                </aside>

                <!-- MAIN CONTENT -->
                <main class="main-content">
                    <h2> Demande d’une autorisation
                    </h2>
                    <div class="page-section">


                        {{-- <img src="{{ asset('images/abrema_import_export.jpg') }}" alt="ABREMA Import Export" class="page-img"> --}}

                        <p class="page-text">
                            La procédure d’obtention d’une autorisation d’importation des médicaments et autres produits
                            de santé se fait via un système automatisé du Guichet Unique Electronique « ASYCUDA ».
                            Ce système permet de mettre en étroite collaboration l’ABREMA et les services douaniers
                            de l’OBR ce qui rend facile et rapide le contrôle d’entrée des médicaments et autres produits
                            de santé sur tout le territoire du pays. Après obtention d’une autorisation d’importation des
                            médicaments et autres produits de santé, l’importateur déclenche la procédure de livraison des
                            produits concernés. A l’arrivée des produits, une inspection physique des produits livrés est
                            effectuée par une équipe des officiers inspecteurs de l’ABREMA pour s’assurer de leur conformité
                            à l’autorisation d’importation et la réglementation en vigueur. Les produits trouvés conformes
                            sont libérés des services douaniers pour la mise en consommation. Les produits non conformes
                            sont mis en quarantaine en attente de leur destruction. LES DOCUMENTS EXIGÉS POUR CONSTITUER
                            UN DOSSIER DE DEMANDE D’AUTORISATION D’IMPORTATION : « Voir note d’instruction du 22/06/2021 ».
                            NB : L’ABREMA se réserve le droit de demander tout document jugé nécessaire pour optimiser
                            l’analyse et le traitement d’une demande d’autorisation d’importation.
                        </p>
                    </div>

                    <div class="page-section">
                        <h2 class="page-section-title">
                            NOTES AUX IMPORTATEURS
                        </h2>
                        <div class="pdf-container" style="width: 100%; height: 800px; margin-top: 20px;">
                            <embed src="{{ asset('files/2025040709010267f3944edf211.pdf') }}" type="application/pdf"
                                width="100%" height="100%">
                        </div>



                        {{-- <img src="" alt="file download" class="page-img"> --}}
                    </div>
                </main>

                <!-- SIDEBAR WIDGETS -->
                <aside>
                    <!-- Avis au public -->
                    <div class="widget">
                        <h3>Avis au Public</h3>

                        @if ($avisPublics->count() == 0)
                            <p class="text-muted small">Pas d'avis au Public pour le moment</p>
                        @else
                            <ul class="list-unstyled">
                                @foreach ($avisPublics as $avis)
                                    <li style="margin-bottom: 12px;">
                                        <strong>{{ $avis->title }}</strong>
                                        <br>

                                        <a href="{{ route('information.evenement') }}" class="btn btn-link p-0"
                                            style="font-size: 0.9rem;">
                                            Lire plus →
                                        </a>
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </div>

                           <!-- Services rapides -->
                    <div class="widget widget-services">
                        <h3>Services Rapides</h3>
                        <a href="{{ route('importexport.demande') }}" class="service-link">
                            <span>Demande d'importation</span>
                        </a>
                        <a href="{{ route('submitcolis') }}" class="service-link">
                            <span>Inspection des colis</span>

                        </a>
                        <a href="{{ route('vigilance.signalement') }}" class="service-link">
                            <span>Signalement PMQIF</span>
                        </a>
                        <a href="{{ route('vigilance.delegue') }}" class="service-link">
                            <span>Délégués médicaux</span>
                        </a>
                    </div>

                    <!-- Liens officiels -->
                    <div class="widget widget-links">
                        <h3>Points d'entrée</h3>
                        <a href="#">Aéroport international Melchior Ndadaye</a>
                        <a href="#">Port de Bujumbura</a>
                        <a href="#">Frontière de Kobero</a>
                        <a href="#">Frontière de Kanyaru haut</a>
                        <a href="#">Frontière Gasenyi Nemba</a>
                        <a href="#">Frontière Gatumba</a>
                    </div>
                </aside>
            </div>
        </div>
    </div>
@endsection
