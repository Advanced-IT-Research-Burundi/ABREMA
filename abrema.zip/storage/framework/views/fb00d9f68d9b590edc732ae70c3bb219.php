<?php $__env->startSection('title', 'Profil de l\'ABREMA'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pages.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- PAGE BANNER -->
    <div class="page-banner">
        <div class="container-fluid">
            <h1>Les évènements</h1>
            <p class="lead">Autorité Burundaise de Régulation des Médicaments à usage humain et des Aliments</p>
        </div>
    </div>

    <!-- MAIN LAYOUT -->
    <div class="main-layout">
        <div class="container-fluid">
            <div class="layout-row">

               <!-- SIDEBAR NAV -->
                <aside class="sidebar-nav">
                    <h3>Navigation</h3>
                    <nav class="nav flex-column">
                        <a class="nav-link <?php echo e(Route::is('about.profilabrema') ? 'active' : ''); ?>" href="<?php echo e(route('about.profilabrema')); ?>">Profil global d'ABREMA</a>
                        <a class="nav-link <?php echo e(Route::is('about.organigramme') ? 'active' : ''); ?>" href="<?php echo e(route('about.organigramme')); ?>">Organigramme</a>
                        <a class="nav-link <?php echo e(Route::is('about.equipe') ? 'active' : ''); ?>" href="<?php echo e(route('about.equipe')); ?>">Équipe de Direction</a>
                        <a class="nav-link <?php echo e(Route::is('about.fonction') ? 'active' : ''); ?>" href="<?php echo e(route('about.fonction')); ?>">Fonction Réglementaire</a>
                        <a class="nav-link <?php echo e(Route::is('about.qms') ? 'active' : ''); ?>" href="<?php echo e(route('about.qms')); ?>">QMS</a>
                    </nav>
                </aside>

                <!-- MAIN CONTENT -->
                <main class="main-content">
                    <h2>Les évènements</h2>

                    <?php if($avisPublics->count() === 0): ?>
                        <p class="text-muted">Aucun avis au public pour le moment.</p>
                    <?php else: ?>
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $avisPublics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li style="margin-bottom: 20px; border-bottom: 1px solid #ddd; padding-bottom: 10px;">
                                    <h4><?php echo e($avis->title); ?></h4>

                                    <p style="margin: 0; color:#444;">
                                        <?php echo e(Str::limit($avis->description, 150)); ?>

                                    </p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                        
                        <?php echo e($avisPublics->links()); ?>

                    <?php endif; ?>
                </main>


                <!-- SIDEBAR WIDGETS -->
                <aside>
                           <!-- Services rapides -->
                    <div class="widget widget-services">
                        <h3>Services Rapides</h3>
                        <a href="<?php echo e(route('importexport.demande')); ?>" class="service-link">
                            <span>Demande d'importation</span>
                        </a>
                        <a href="<?php echo e(route('submitcolis')); ?>" class="service-link">
                            <span>Inspection des colis</span>

                        </a>
                        <a href="<?php echo e(route('vigilance.signalement')); ?>" class="service-link">
                            <span>Signalement PMQIF</span>
                        </a>
                        <a href="<?php echo e(route('vigilance.delegue')); ?>" class="service-link">
                            <span>Délégués médicaux</span>
                        </a>
                    </div>

                    <!-- Liens officiels -->
                    <div class="widget widget-links">
                        <h3>Points d'entrée</h3>
                        <a href="#">Aéroport international Melchior Ndadaye</a>
                        <a href="#">Port de Bujumbura</a>
                        <a href="#">Frontière de Kobero</a>
                        <a href="#">Frontière de Kanyaru haut</a>
                        <a href="#">Frontière Gasenyi Nemba</a>
                        <a href="#">Frontière Gatumba</a>
                    </div>
                </aside>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/information/evenement.blade.php ENDPATH**/ ?>