<?php $__env->startSection('title', 'Modifier un partenaire'); ?>
<?php $__env->startSection('page-title', 'Modifier un partenaire'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">

    <!-- Breadcrumb -->
    <nav class="mb-6">
        <ol class="flex items-center space-x-2 text-sm text-gray-600">
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="hover:text-green-600">Dashboard</a>
            </li>
            <li><i class="fas fa-chevron-right text-xs"></i></li>
            <li>
                <a href="<?php echo e(route('admin.partenaires.index')); ?>" class="hover:text-green-600">
                    Partenaires
                </a>
            </li>
            <li><i class="fas fa-chevron-right text-xs"></i></li>
            <li class="text-gray-900 font-medium">Modifier</li>
        </ol>
    </nav>

    <!-- Form Card -->
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6 border-b border-gray-200">
            <h2 class="text-xl font-bold text-gray-800">Modifier le partenaire</h2>
            <p class="text-gray-600 mt-1">
                Mettez à jour les informations du partenaire
            </p>
        </div>

        <form action="<?php echo e(route('admin.partenaires.update', $partenaire)); ?>"
              method="POST"
              enctype="multipart/form-data"
              class="p-6 space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Nom -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Nom du partenaire <span class="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    name="nom"
                    value="<?php echo e(old('nom', $partenaire->nom)); ?>"
                    class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500
                    <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    required
                >
                <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Lien -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Site web <span class="text-red-500">*</span>
                </label>
                <input
                    type="url"
                    name="link"
                    value="<?php echo e(old('link', $partenaire->link)); ?>"
                    placeholder="https://www.example.com"
                    class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500
                    <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    required
                >
                <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Description -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Description <span class="text-red-500">*</span>
                </label>
                <textarea
                    name="description"
                    rows="5"
                    class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    required
                ><?php echo e(old('description', $partenaire->description)); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Logo -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Logo
                </label>

                <?php if($partenaire->logo): ?>
                    <div class="mb-4">
                        <p class="text-sm text-gray-600 mb-2">Logo actuel :</p>
                        <img
                            src="<?php echo e(Storage::url($partenaire->logo)); ?>"
                            class="w-full h-48 object-contain rounded-lg border"
                        >
                    </div>
                <?php endif; ?>

                <div class="flex items-center justify-center w-full">
                    <label class="flex flex-col items-center justify-center w-full h-48 border-2
                                  border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                        <div class="flex flex-col items-center justify-center pt-5 pb-6">
                            <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"></i>
                            <p class="text-sm text-gray-500">
                                <span class="font-semibold">Cliquez pour remplacer</span> ou glissez-déposez
                            </p>
                            <p class="text-xs text-gray-500">PNG, JPG, SVG (max 2MB)</p>
                        </div>
                        <input type="file" name="logo" accept="image/*" class="hidden"
                               onchange="previewImage(event)">
                    </label>
                </div>

                <div id="imagePreview" class="mt-4 hidden">
                    <img id="preview" class="w-full h-48 object-contain rounded-lg border">
                </div>

                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Actions -->
            <div class="flex justify-end space-x-4 pt-6 border-t">
                <a href="<?php echo e(route('admin.partenaires.index')); ?>"
                   class="px-6 py-2 border rounded-lg">
                    Annuler
                </a>
                <button class="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                    <i class="fas fa-save mr-2"></i>Mettre à jour
                </button>
            </div>
        </form>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function previewImage(event) {
    const reader = new FileReader();
    reader.onload = e => {
        document.getElementById('preview').src = e.target.result;
        document.getElementById('imagePreview').classList.remove('hidden');
    };
    reader.readAsDataURL(event.target.files[0]);
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/admin/partenaires/edit.blade.php ENDPATH**/ ?>