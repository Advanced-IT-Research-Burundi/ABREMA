<?php $__env->startSection('title', 'Textes Reglementaires-Medicaments'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pages.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- PAGE BANNER -->
    <div class="page-banner">
        <div class="container-fluid">
            <h1>Texte Réglementaire sur les Médicaments</h1>
            <p class="lead">Autorité Burundaise de Régulation des Médicaments à usage humain et des Aliments</p>
        </div>
    </div>

    <!-- MAIN LAYOUT -->
    <div class="main-layout">
        <div class="container-fluid">
            <div class="layout-row">

               <!-- SIDEBAR NAV -->
                <aside class="sidebar-nav">
                    <h3>Navigation</h3>
                    <nav class="nav flex-column">
                        <a class="nav-link <?php echo e(Route::is('about.profilabrema') ? 'active' : ''); ?>" href="<?php echo e(route('about.profilabrema')); ?>">Profil global d'ABREMA</a>
                        <a class="nav-link <?php echo e(Route::is('about.organigramme') ? 'active' : ''); ?>" href="<?php echo e(route('about.organigramme')); ?>">Organigramme</a>
                        <a class="nav-link <?php echo e(Route::is('about.equipe') ? 'active' : ''); ?>" href="<?php echo e(route('about.equipe')); ?>">Équipe de Direction</a>
                        <a class="nav-link <?php echo e(Route::is('about.fonction') ? 'active' : ''); ?>" href="<?php echo e(route('about.fonction')); ?>">Fonction Réglementaire</a>
                        <a class="nav-link <?php echo e(Route::is('about.qms') ? 'active' : ''); ?>" href="<?php echo e(route('about.qms')); ?>">QMS</a>
                    </nav>
                </aside>

                <!-- MAIN CONTENT -->
                <main class="main-content">
                    <div class="page-section">
                        <h2 class="page-section-title">
                            Texte Réglementaire sur les Médicaments
                        </h2>
                        <!-- <div class="page-img">
                                            <img src="<?php echo e(asset('images/abrema_regulations.jpg')); ?>" alt="ABREMA Regulations" class="page-img">
                                        </div> -->
                        <p class="page-text">
                            Les textes réglementaires relatifs aux médicaments sont disponibles pour consultation.
                        </p>
                    </div>
                    <div class="pdf-container" style="width: 100%; height: 800px; margin-top: 20px;">
                        <embed src="<?php echo e(asset('files/2025040709113467f396c6ebca6.pdf')); ?>" type="application/pdf"
                            width="100%" height="100%">
                    </div>

                    <div class="page-text">
                        ORDONNANCE MINISTÉRIELLE CONJOINTE N°630/540/219 DU 12/08/2025 PORTANT FIXATION DES REDEVANCES
                        ADMINISTRATIVES
                        POUR LES SERVICES OFFERTS PAR L'AUTORITÉ BURUNDAISE DE RÉGULATION DES MÉDICAMENTS À USAGE HUMAIN ET
                        DES ALIMENTS
                        « ABREMA » EN APPLICATION DE L’ARTICLE 172 DE LA LOI DE FINANCES, EXERCICE 2025/2026
                    </div>


                    2025040808411767f4e1234455eK

                    <div class="pdf-container" style="width: 100%; height: 800px; margin-top: 20px;">
                        <embed src="<?php echo e(asset('files/2025040808411767f4e1234455eK.pdf')); ?>" type="application/pdf"
                        width="100%" height="100%">
                    </div>
                </main>

                 <!-- SIDEBAR WIDGETS -->
                <aside>
                    <!-- Avis au public -->
                    <div class="widget">
                        <h3>Avis au Public</h3>

                        <?php if($avisPublics->count() == 0): ?>
                            <p class="text-muted small">Pas d'avis au Public pour le moment</p>
                        <?php else: ?>
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $avisPublics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="margin-bottom: 12px;">
                                        <strong><?php echo e($avis->title); ?></strong>
                                        <br>

                                        <a href="<?php echo e(route('information.evenement')); ?>" class="btn btn-link p-0"
                                            style="font-size: 0.9rem;">
                                            Lire plus →
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                           <!-- Services rapides -->
                    <div class="widget widget-services">
                        <h3>Services Rapides</h3>
                        <a href="<?php echo e(route('importexport.demande')); ?>" class="service-link">
                            <span>Demande d'importation</span>
                        </a>
                        <a href="<?php echo e(route('submitcolis')); ?>" class="service-link">
                            <span>Inspection des colis</span>

                        </a>
                        <a href="<?php echo e(route('vigilance.signalement')); ?>" class="service-link">
                            <span>Signalement PMQIF</span>
                        </a>
                        <a href="<?php echo e(route('vigilance.delegue')); ?>" class="service-link">
                            <span>Délégués médicaux</span>
                        </a>
                    </div>

                    <!-- Liens officiels -->
                    <div class="widget widget-links">
                        <h3>Points d'entrée</h3>
                        <a href="#">Aéroport international Melchior Ndadaye</a>
                        <a href="#">Port de Bujumbura</a>
                        <a href="#">Frontière de Kobero</a>
                        <a href="#">Frontière de Kanyaru haut</a>
                        <a href="#">Frontière Gasenyi Nemba</a>
                        <a href="#">Frontière Gatumba</a>
                    </div>
                </aside>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/medicament/texte.blade.php ENDPATH**/ ?>