<?php $__env->startSection('title', 'Équipe Direction'); ?>
<?php $__env->startSection('page-title', 'Équipe Direction'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h2 class="text-2xl font-bold text-gray-800">Équipe de Direction</h2>
        <a href="<?php echo e(route('admin.equipe-directions.create')); ?>" class="px-6 py-3 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition">
            <i class="fas fa-plus mr-2"></i> Ajouter un Membre
        </a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $equipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-lg transition">
            <?php if($membre->photo): ?>
                <img src="<?php echo e(Storage::url($membre->photo)); ?>" alt="<?php echo e($membre->nom_prenom); ?>" class="w-full h-64 object-cover">
            <?php else: ?>
                <div class="w-full h-64 bg-gradient-to-br from-teal-100 to-teal-200 flex items-center justify-center">
                    <i class="fas fa-user text-6xl text-teal-400"></i>
                </div>
            <?php endif; ?>
            
            <div class="p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-2"><?php echo e($membre->nom_prenom); ?></h3>
                <p class="text-sm text-teal-600 mb-3">
                    <i class="fas fa-envelope mr-2"></i><?php echo e($membre->email); ?>

                </p>
                <p class="text-sm text-gray-600 mb-4 line-clamp-3"><?php echo e($membre->description); ?></p>
                
                <div class="flex space-x-2 pt-4 border-t">
                    <a href="<?php echo e(route('admin.equipe-directions.edit', $membre->id)); ?>" class="flex-1 px-3 py-2 text-center bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition text-sm">
                        <i class="fas fa-edit mr-1"></i> Modifier
                    </a>
                    <form method="POST" action="<?php echo e(route('admin.equipe-directions.destroy', $membre->id)); ?>" onsubmit="return confirm('Supprimer ce membre?')" class="flex-1">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="w-full px-3 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition text-sm">
                            <i class="fas fa-trash mr-1"></i> Supprimer
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-3 bg-white rounded-xl shadow-sm p-12 text-center">
            <i class="fas fa-users text-6xl text-gray-300 mb-4"></i>
            <p class="text-gray-500 mb-4">Aucun membre dans l'équipe</p>
            <a href="<?php echo e(route('admin.equipe-directions.create')); ?>" class="inline-flex items-center px-6 py-3 bg-teal-600 text-white rounded-lg hover:bg-teal-700">
                <i class="fas fa-plus mr-2"></i> Ajouter un membre
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/admin/equipe/index.blade.php ENDPATH**/ ?>