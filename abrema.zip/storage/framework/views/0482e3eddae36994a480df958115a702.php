<?php $__env->startSection('title', 'Text reglementaire sur la vigilance et Publicité'); ?>
<?php $__env->startSection('content'); ?>

    <div class="page-wrapper">

    <div class="page-section">
        <h2 class="page-section-title">
            Text réglementaire sur la vigilance et Publicité
        </h2>

        <div class="page-img">
            <img src="" alt="File Download" class="page-img">
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/vigilance/texte.blade.php ENDPATH**/ ?>