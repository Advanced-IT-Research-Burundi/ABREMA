<?php $__env->startSection('title', 'Gestion des Partenaires'); ?>
<?php $__env->startSection('page-title', 'Partenaires'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h2 class="text-2xl font-bold text-gray-800">Nos Partenaires</h2>
        <a href="<?php echo e(route('admin.partenaires.create')); ?>" class="px-6 py-3 text-white transition bg-purple-600 rounded-lg hover:bg-purple-700">
            <i class="mr-2 fas fa-plus"></i> Nouveau Partenaire
        </a>
    </div>

    <div class="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
        <?php $__empty_1 = true; $__currentLoopData = $partenaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partenaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="p-6 transition bg-white shadow-sm rounded-xl hover:shadow-lg group">
            <?php if($partenaire->logo): ?>
                <div class="flex items-center justify-center h-32 p-4 mb-4 rounded-lg bg-gray-50">
                    <img src="<?php echo e(asset("uploads/".$partenaire->logo)); ?>" alt="<?php echo e($partenaire->nom); ?>" class="object-contain max-w-full max-h-full transition group-hover:scale-110">
                </div>
            <?php else: ?>
                <div class="flex items-center justify-center h-32 mb-4 rounded-lg bg-gradient-to-br from-purple-100 to-purple-200">
                    <i class="text-5xl text-purple-400 fas fa-handshake"></i>
                </div>
            <?php endif; ?>
            
            <h3 class="mb-2 text-lg font-semibold text-center text-gray-800"><?php echo e($partenaire->nom); ?></h3>
            
            <?php if($partenaire->description): ?>
                <p class="mb-4 text-sm text-center text-gray-600 line-clamp-2"><?php echo e($partenaire->description); ?></p>
            <?php endif; ?>

            <?php if($partenaire->link): ?>
                <a href="<?php echo e($partenaire->link); ?>" target="_blank" class="block mb-4 text-xs text-center text-purple-600 hover:text-purple-700">
                    <i class="mr-1 fas fa-external-link-alt"></i> Visiter le site
                </a>
            <?php endif; ?>

            <div class="flex pt-4 space-x-2 border-t">
                <a href="<?php echo e(route('admin.partenaires.edit', $partenaire->id)); ?>" class="flex-1 px-3 py-2 text-sm text-center text-green-600 transition rounded-lg bg-green-50 hover:bg-green-100">
                    <i class="fas fa-edit"></i>
                </a>
                <form method="POST" action="<?php echo e(route('admin.partenaires.destroy', $partenaire->id)); ?>" onsubmit="return confirm('Supprimer ce partenaire?')" class="flex-1">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="w-full px-3 py-2 text-sm text-red-600 transition rounded-lg bg-red-50 hover:bg-red-100">
                        <i class="fas fa-trash"></i>
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-4 p-12 text-center bg-white shadow-sm rounded-xl">
            <i class="mb-4 text-6xl text-gray-300 fas fa-handshake"></i>
            <p class="mb-4 text-gray-500">Aucun partenaire</p>
            <a href="<?php echo e(route('admin.partenaires.create')); ?>" class="inline-flex items-center px-6 py-3 text-white bg-purple-600 rounded-lg hover:bg-purple-700">
                <i class="mr-2 fas fa-plus"></i> Ajouter un partenaire
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/admin/partenaires/index.blade.php ENDPATH**/ ?>