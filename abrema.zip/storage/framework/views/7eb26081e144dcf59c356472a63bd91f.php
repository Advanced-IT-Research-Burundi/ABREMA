<?php $__env->startSection('title', 'Colis'); ?>
<?php $__env->startSection('page-title', 'Liste des Colis soumis'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h2 class="text-2xl font-bold text-gray-800">Colis soumis</h2>
            <p class="text-gray-600 mt-1">Tous les colis envoyés par les utilisateurs</p>
        </div>
    </div>
    
    <!-- Table -->
    <div class="bg-white rounded-lg shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom et Prénom</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Téléphone</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Message</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fichier</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilisateur</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $colis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($c->nom_prenom); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($c->email); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($c->phone ?? '-'); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-700"><?php echo e(Str::limit($c->message, 50)); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-700">
                                <?php if($c->pathfile): ?>
                                    <a href="<?php echo e(asset('storage/'.$c->pathfile)); ?>" class="text-blue-600 hover:underline" target="_blank">Voir</a>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($c->user?->name ?? '-'); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($c->created_at->format('d/m/Y H:i')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center text-gray-400">
                                Aucun colis soumis pour le moment.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if($colis->hasPages()): ?>
            <div class="px-6 py-4 border-t border-gray-200">
                <?php echo e($colis->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/admin/colis/index.blade.php ENDPATH**/ ?>