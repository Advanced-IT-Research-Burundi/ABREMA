<?php $__env->startSection('title', 'Point Entrees'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

    <div class="page-section">
        <h2 class="page-section-title">
            Points d'Entrées
        </h2>

        <ul class="page-list">
            <li>Aéroport international Melchior Ndadaye</li>
            <li>Port de Bujumbura</li>
            <li>Port de Bujumbura</li>
            <li>Frontière de Kobero</li>
            <li>Frontière de Kanyaru haut</li>
            <li>Frontière Gasenyi Nemba</li>
            <li>Frontière Gatumba</li>
        </ul>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/ImportExport/pointentree.blade.php ENDPATH**/ ?>