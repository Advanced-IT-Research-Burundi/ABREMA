<?php $__env->startSection('title', 'Détails du produit'); ?>
<?php $__env->startSection('page-title', 'Détails du Produit'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a> /
    <a href="<?php echo e(route('admin.produits.index')); ?>">Produits</a> /
    <span>Détails</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><?php echo e($produit->nom); ?></h3>
        <a href="<?php echo e(route('admin.produits.edit', $produit->id)); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-edit"></i> Modifier
        </a>
    </div>

    <div class="card-body">
        <div style="display: flex; gap: 30px;">
            <?php if($produit->image): ?>
                <img src="<?php echo e(asset('storage/'.$produit->image)); ?>" width="200" style="border-radius: 8px;">
            <?php else: ?>
                <div style="width:200px;height:200px;background:#EEE;border-radius:8px;display:flex;align-items:center;justify-content:center;">
                    <i class="fas fa-image" style="font-size:40px;color:#AAA;"></i>
                </div>
            <?php endif; ?>

            <div style="flex:1;">
                <p><strong>Nom :</strong> <?php echo e($produit->nom); ?></p>
                <p><strong>Description :</strong> <?php echo e($produit->description); ?></p>
                <p><strong>Prix :</strong> <?php echo e(number_format($produit->prix, 2, ',', ' ')); ?> FBU</p>
                <p><strong>Créé le :</strong> <?php echo e($produit->created_at->format('d/m/Y H:i')); ?></p>

                <a href="<?php echo e(route('admin.produits.index')); ?>" class="btn btn-secondary" style="margin-top:20px;">
                    Retour
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/admin/produits/show.blade.php ENDPATH**/ ?>