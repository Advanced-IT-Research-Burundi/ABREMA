<?php $__env->startSection('title', 'colis'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pages.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- PAGE BANNER -->
    <div class="page-banner">
        <div class="container-fluid">
            <h1>Inspection des Colis</h1>
            <p class="lead">Autorité Burundaise de Régulation des Médicaments à usage humain et des Aliments</p>
        </div>
    </div>

    <!-- MAIN LAYOUT -->
    <div class="main-layout">
        <div class="container-fluid">
            <div class="layout-row">

                <!-- SIDEBAR NAV -->
                <aside class="sidebar-nav">
                    <h3>Navigation</h3>
                    <nav class="nav flex-column">
                        <a class="nav-link active" href="<?php echo e(route('about.profilabrema')); ?>">Profil global d'ABREMA</a>
                        <a class="nav-link" href="<?php echo e(route('about.organigramme')); ?>">Organigramme</a>
                        <a class="nav-link" href="<?php echo e(route('about.equipe')); ?>">Équipe de Direction</a>
                        <a class="nav-link" href="<?php echo e(route('about.fonction')); ?>">Fonction Réglementaire</a>
                        <a class="nav-link" href="<?php echo e(route('about.qms')); ?>">QMS</a>
                    </nav>
                </aside>

                <!-- MAIN CONTENT -->
                <main class="main-content">
                    <h2 class="form-title">Soumettre un colis</h2>
                    <div class="page-section">

                        
                        <?php if(session('success')): ?>
                            <div class="alert alert-success page-text"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger page-text">
                                <strong>Veuillez corriger les erreurs ci-dessous :</strong>
                            </div>
                        <?php endif; ?>

                        <div class="info-box full-row">
                            <h4 class="page-section-title">Avant de compléter le formulaire</h4>
                            <ol class="page-text" style="margin:12px 0 0 18px; padding:0;">
                                <li>Télécharger le formulaire ci-joint — <a
                                        href="<?php echo e(asset('doc/FORMULAIRE_DE_DEMANDE_INSPECTION_DES_COLIS.docx')); ?>" download
                                        class="result-link">Télécharger</a></li>
                                <li>Le remplir et le signer</li>
                                <li>Puis le téléverser sur notre plateforme.</li>
                            </ol>
                        </div>
                        <form action="<?php echo e(route('submitcolis')); ?>" method="POST" enctype="multipart/form-data"
                            class="page-form">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label class="form-label page-text">Nom de l'expéditeur</label>
                                <input type="text" name="nom_prenom"
                                    class="form-control <?php $__errorArgs = ['nom_prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('nom_prenom')); ?>" required>
                                <?php $__errorArgs = ['nom_prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback page-text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label class="form-label page-text">Téléphone</label>
                                <input type="tel" name="phone"
                                    class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>"
                                    required>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback page-text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label class="form-label page-text">Email</label>
                                <input type="email" name="email"
                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>"
                                    required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback page-text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label class="form-label page-text">Message / Description</label>
                                <textarea name="message" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="4" required><?php echo e(old('message')); ?></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback page-text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-note">
                                Une fois le formulaire de demande d'inspection des colis signé et rempli, veuillez le
                                téléverser ici! (fichier .pdf)
                            </div>

                            <div class="mb-3">
                                <label class="form-label page-text">Fichier joint (optionnel)</label>
                                <input type="file" name="pathfile"
                                    class="form-control <?php $__errorArgs = ['pathfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                                <?php $__errorArgs = ['pathfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback page-text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="text-muted page-text">
                                    Formats acceptés : PDF, DOC, DOCX, JPG, PNG (Max 5MB)
                                </small>
                            </div>

                            <button type="submit" class="btn btn-primary">Soumettre le colis</button>
                        </form>
                    </div>

                </main>

                <!-- SIDEBAR WIDGETS -->
                <aside>
                    <!-- Avis au public -->
                    <div class="widget">
                        <h3>Avis au Public</h3>

                        <?php if($avisPublics->count() == 0): ?>
                            <p class="text-muted small">Pas d'avis au Public pour le moment</p>
                        <?php else: ?>
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $avisPublics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="margin-bottom: 12px;">
                                        <strong><?php echo e($avis->title); ?></strong>
                                        <br>

                                        <a href="<?php echo e(route('information.evenement')); ?>" class="btn btn-link p-0"
                                            style="font-size: 0.9rem;">
                                            Lire plus →
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <!-- Services rapides -->
                    <div class="widget widget-services">
                        <h3>Services Rapides</h3>
                        <a href="<?php echo e(route('importexport.demande')); ?>" class="service-link">
                            <span>Demande d'importation</span>
                            <i class="fas fa-arrow-right"></i>
                        </a>
                        
                        <a href="<?php echo e(route('vigilance.signalement')); ?>" class="service-link">
                            <span>Signalement PMQIF</span>
                            <i class="fas fa-arrow-right"></i>
                        </a>
                        <a href="<?php echo e(route('vigilance.delegue')); ?>" class="service-link">
                            <span>Délégués médicaux</span>
                            <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>

                    <!-- Liens officiels -->
                    <div class="widget widget-links">
                        <h3>Points d'entrée</h3>
                        <a href="#">Aéroport international Melchior Ndadaye</a>
                        <a href="#">Port de Bujumbura</a>
                        <a href="#">Frontière de Kobero</a>
                        <a href="#">Frontière de Kanyaru haut</a>
                        <a href="#">Frontière Gasenyi Nemba</a>
                        <a href="#">Frontière Gatumba</a>
                    </div>
                </aside>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nijea\Documents\CODE\CODE\ADVANCED 2025\ABREMA\abrema\resources\views/service/colis.blade.php ENDPATH**/ ?>