<?php

namespace App\Http\Controllers;

use App\Http\Requests\NotificationStoreRequest;
use App\Http\Requests\NotificationUpdateRequest;
use App\Http\Resources\NotificationCollection;
use App\Http\Resources\NotificationResource;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class NotificationController extends Controller
{
    public function index(Request $request)
    {
        $notifications = Notification::all();

        return new NotificationCollection($notifications);
    }

    public function store(NotificationStoreRequest $request)
    {
        $notification = Notification::create($request->validated());

        return new NotificationResource($notification);
    }

    public function show(Request $request, Notification $notification)
    {
        return new NotificationResource($notification);
    }

    public function update(NotificationUpdateRequest $request, Notification $notification)
    {
        $notification->update($request->validated());

        return new NotificationResource($notification);
    }

    public function destroy(Request $request, Notification $notification)
    {
        $notification->delete();

        return response()->noContent();
    }
}
